
var slides = document.querySelector('.slides'),
	slide_wrapper = document.querySelector('.slide_wrapper'),
	slide = document.querySelectorAll('.slides li'),
	img = document.querySelectorAll('.slides li img')

currentIndex = 0,
	slideCount = slide.length,
	slideWidth = 400,
	slideMargin = 0,
	prevBtn = document.querySelector('.prev'),
	nextBtn = document.querySelector('.next');

var MAX_WIDTH = 700;
var MAX_HEIGHT = 700;

var tempImg = new Image();
var tempImg2 = new Image();
var img_padding = new Image();

var img_padding_add = 0;

var img_width = 0;
var img_height = 0;
let img_li_width = 0;


for (var i = 0; i < img.length; i++) {

	//가로가 큰 경우 
	if (img[i].width > img[i].height) {
		if (img[i].width > MAX_WIDTH) {
			img[i].height *= MAX_WIDTH / img[i].width;
			img[i].style.width = MAX_WIDTH;
		}
	}
	else {
		if (img[i].height > MAX_HEIGHT) {
			img[i].width *= MAX_HEIGHT / img[i].height;
			img[i].style.height = MAX_HEIGHT;
		}
	}
}

for (var i = 0; i < img.length; i++) {

	if (img[i].height >= img_height) {
		img_height = img[i].height;
	};

	if (img[i].width >= img_width) {
		img_width = img[i].width;
	};

	img_li_width += img[i].width;



	tempImg2.width = img_li_width;

	tempImg.width = img_width;
	tempImg.height = img_height;

};

for (var i = 0; i < img.length; i++) {

	if (img[i].width < tempImg.width) {
		var img_blank_width = Math.floor((tempImg.width - img[i].width) / 2);
		img[i].style.padding = "0px " + img_blank_width + "px";
		img_padding_add += img_blank_width;
	};

	if (img[i].height < tempImg.height) {
		var img_blank_height = Math.floor((tempImg.height - img[i].height) / 2);
		img[i].style.padding = img_blank_height + "px " + "0px";
		// img_padding_add += img_blank_height;
	}
}


slide_wrapper.style.width = tempImg.width + 'px';
slide_wrapper.style.height = tempImg.height + 'px';
slides.style.width = tempImg2.width + (img_padding_add * 2) + 'px';


function moveSlide(num) {
	slides.style.left = -num * (MAX_WIDTH) + 'px';
	currentIndex = num;
}

nextBtn.addEventListener('click', function () {
	if (currentIndex < slideCount - 1) {
		moveSlide(currentIndex + 1);
	} else {
		moveSlide(0);
	}
});

prevBtn.addEventListener('click', function () {
	if (currentIndex > 0) {
		moveSlide(currentIndex - 1);
	} else {
		moveSlide(slideCount - 1);
	}
});